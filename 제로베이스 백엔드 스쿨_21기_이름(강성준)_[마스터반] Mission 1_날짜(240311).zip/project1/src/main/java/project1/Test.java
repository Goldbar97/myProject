package project1;

import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {		
		WifiDAO wifiDAO = new WifiDAO();
		wifiDAO.connect();
		
		System.out.println(wifiDAO.isValidTable("wifi_info"));
		
		wifiDAO.disconnect();
	}
}
