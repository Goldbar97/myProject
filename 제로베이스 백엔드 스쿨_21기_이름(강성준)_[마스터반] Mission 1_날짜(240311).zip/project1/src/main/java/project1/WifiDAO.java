package project1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.google.gson.Gson;

import project1.WifiJson.TbPublicWifiInfo.Row;

public class WifiDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private int totalWifiCount;
	
	public WifiDAO() {
		conn = null;
		pstmt = null;
		rs = null;
	}
	
	public boolean isValidTable(String name) {
		if (conn == null) {
			System.out.println("Null Connection");
			return false;
		}
		
		int result = 0;
		
		try {
			String sql = String.format("select exists (select 1 from information_schema.tables where table_schema = 'wifi_db' and table_name like '%s') as success;", name);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				result = rs.getInt(1);
			}
			
			if (result > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public int getTotalWifiCount() {
		return totalWifiCount;
	}
	
	public int setAndGetTotalWifiCount() {
		if (conn == null) {
			System.out.println("Null Connection");
			return 0;
		}
		
		try {
			String sql = "select count(*) from wifi_info;";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				totalWifiCount = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return totalWifiCount;
	}
	
	public void connect() {
		try {
			String dbURL = "jdbc:mariadb://localhost:3306/wifi_db";
			String dbUser = "wifi_user";
			String dbPassword = "wifi_user";
			Class.forName("org.mariadb.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void disconnect() {
		try {
			if (rs != null && !rs.isClosed()) {
				rs.close();
				rs = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
            if (pstmt != null && !pstmt.isClosed()) {
            	pstmt.close();
            	pstmt = null;
            }
        } catch (Exception e) {
        	e.printStackTrace();
        }
		
		try {
			if (conn != null && !conn.isClosed()) {
				conn.close();
				conn = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean isEmpty() {
		if (conn == null) {
			System.out.println("Null Connection");
			return true;
		}
		
		int success = 0;
		
		try {
			String sql = "select exists (select * from wifi_info limit 1) as success;";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				success = rs.getInt("success");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (success > 0) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean isEmptyHistory() {
		if (conn == null) {
			System.out.println("Null Connection");
			return true;
		}
		
		int success = 0;
		
		try {
			String sql = "select exists (select * from location_history limit 1) as success;";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				success = rs.getInt("success");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (success > 0) {
			return false;
		} else {
			return true;
		}
	}
	
	public boolean isEmptyBookmark() {
		if (conn == null) {
			System.out.println("Null Connection");
			return true;
		}
		
		int success = 0;
		
		try {
			String sql = "select exists (select 1 from information_schema.tables where table_schema = 'wifi_db' and table_name like '%bookmark%') as success;";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				success = rs.getInt("success");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (success > 0) {
			return false;
		} else {
			return true;
		}
	}
	
	public void create() {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		}
		
		try {
			StringBuilder sb = new StringBuilder();
			String sql;
			
			sb.append("CREATE TABLE WIFI_INFO (\r\n");
			sb.append("	X_SWIFI_MGR_NO      VARCHAR(255) NOT NULL COMMENT '관리번호',\r\n");
			sb.append("	X_SWIFI_WRDOFC      VARCHAR(255) NULL     COMMENT '자치구',\r\n");
			sb.append("	X_SWIFI_MAIN_NM     VARCHAR(255) NULL     COMMENT '와이파이명',\r\n");
			sb.append("	X_SWIFI_ADRES1      VARCHAR(255) NULL     COMMENT '도로명주소',\r\n");
			sb.append("	X_SWIFI_ADRES2      VARCHAR(255) NULL     COMMENT '상세주소',\r\n");
			sb.append("	X_SWIFI_INSTL_FLOOR VARCHAR(255) NULL     COMMENT '설치위치(층)',\r\n");
			sb.append("	X_SWIFI_INSTL_TY    VARCHAR(255) NULL     COMMENT '설치유형',\r\n");
			sb.append("	X_SWIFI_INSTL_MBY   VARCHAR(255) NULL     COMMENT '설치기관',\r\n");
			sb.append("	X_SWIFI_SVC_SE      VARCHAR(255) NULL     COMMENT '서비스구분',\r\n");
			sb.append("	X_SWIFI_CMCWR       VARCHAR(255) NULL     COMMENT '망종류',\r\n");
			sb.append("	X_SWIFI_CNSTC_YEAR  VARCHAR(255) NULL     COMMENT '설치년도',\r\n");
			sb.append("	X_SWIFI_INOUT_DOOR  VARCHAR(255) NULL     COMMENT '실내외구분',\r\n");
			sb.append("	X_SWIFI_REMARS3     VARCHAR(255) NULL     COMMENT 'WIFI접속환경',\r\n");
			sb.append("	LAT                 VARCHAR(255) NULL     COMMENT 'Y좌표',\r\n");
			sb.append("	LNT                 VARCHAR(255) NULL     COMMENT 'X좌표',\r\n");
			sb.append("	WORK_DTTM           DATETIME     NULL     COMMENT '작업일자'\r\n");
			sb.append(")\r\n");
			sb.append("COMMENT 'TABLE';");
			
			sql = sb.toString();
			sb.setLength(0);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
			
			sb.append("ALTER TABLE WIFI_INFO\r\n");
			sb.append("	ADD CONSTRAINT PK_WIFI_INFO\r\n");
			sb.append("	PRIMARY KEY (\r\n");
			sb.append("	X_SWIFI_MGR_NO\r\n");
			sb.append("	);");
			
			sql = sb.toString();
			sb.setLength(0);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void save() {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		} else if (!this.isValidTable("wifi_info")) {
			this.create();
		} else if (!this.isEmpty()) {
			System.out.println("Data Conflict");
			System.out.println("Updating Data Instead of Saving");
			this.update();
			return;
		}
		
		try {
			String URL = "http://openapi.seoul.go.kr:8088/51554a537573656f373565746c7558/json/TbPublicWifiInfo/1/1/";
			URL url = new URL(URL);
			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setRequestMethod("GET");
			httpConn.setRequestProperty("Content-type", "application/json");
			BufferedReader br;
			
			if(httpConn.getResponseCode() >= 200 && httpConn.getResponseCode() <= 300) {
				br = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(httpConn.getErrorStream()));
			}
			
			StringBuilder sb = new StringBuilder();
			String line;
			
			while ((line = br.readLine()) != null) {
					sb.append(line);
			}
			
			Gson gson = new Gson();
			WifiJson wifiJson = gson.fromJson(sb.toString(), WifiJson.class);
			Row[] wifiRows;
			int listTotalCount = wifiJson.getTbPublicWifiInfo().getList_total_count();
			totalWifiCount = listTotalCount;
			int totalPage = listTotalCount / 1000;
			int remainTotalCount = listTotalCount % 1000;
			totalPage = remainTotalCount == 0 ? totalPage : totalPage++ ;
			sb.setLength(0);
			
			
			for (int i = 0; i < totalPage; i++) {
				String urlFormat;
				if (i == (totalPage-1)) {
					urlFormat = String.format("http://openapi.seoul.go.kr:8088/51554a537573656f373565746c7558/json/TbPublicWifiInfo/%d/%d/", i*1000+1, i*1000+remainTotalCount);
				} else {
					urlFormat = String.format("http://openapi.seoul.go.kr:8088/51554a537573656f373565746c7558/json/TbPublicWifiInfo/%d/%d/", i*1000+1, (i+1)*1000);
				}
				
				url = new URL(urlFormat);
				httpConn = (HttpURLConnection) url.openConnection();
				httpConn.setRequestMethod("GET");
				httpConn.setRequestProperty("Content-type", "application/json");
				
				br = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
				
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}
				wifiJson = gson.fromJson(sb.toString(), WifiJson.class);
				wifiRows = wifiJson.getTbPublicWifiInfo().getRow();
				sb.setLength(0);
				
				String sql = "insert into wifi_info (X_SWIFI_MGR_NO, X_SWIFI_WRDOFC, X_SWIFI_MAIN_NM, X_SWIFI_ADRES1, X_SWIFI_ADRES2, X_SWIFI_INSTL_FLOOR, X_SWIFI_INSTL_TY, X_SWIFI_INSTL_MBY, X_SWIFI_SVC_SE, X_SWIFI_CMCWR, X_SWIFI_CNSTC_YEAR, X_SWIFI_INOUT_DOOR, X_SWIFI_REMARS3, LAT, LNT, WORK_DTTM) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
				pstmt = conn.prepareStatement(sql);
				int affected = 0;
				
				for (int j = 0; j < wifiRows.length; j++) {
					pstmt.setString(1, wifiRows[j].getMgrNo());
					pstmt.setString(2, wifiRows[j].getWrdofc());
					pstmt.setString(3, wifiRows[j].getMainNm());
					pstmt.setString(4, wifiRows[j].getAdres1());
					pstmt.setString(5, wifiRows[j].getAdres2());
					pstmt.setString(6, wifiRows[j].getInstlFloor());
					pstmt.setString(7, wifiRows[j].getInstlTy());
					pstmt.setString(8, wifiRows[j].getInstlMby());
					pstmt.setString(9, wifiRows[j].getSvcSe());
					pstmt.setString(10, wifiRows[j].getCmcwr());
					pstmt.setString(11, wifiRows[j].getCnstcYear());
					pstmt.setString(12, wifiRows[j].getInoutDoor());
					pstmt.setString(13, wifiRows[j].getRemars3());
					pstmt.setString(14, wifiRows[j].getLat());
					pstmt.setString(15, wifiRows[j].getLnt());
					pstmt.setString(16, wifiRows[j].getWorkDttm());
				
					affected = pstmt.executeUpdate();
				}
				
				if (affected > 0) {
					System.out.println("Success");
				} else {
					System.out.println("Fail");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void update() {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		}
		
		try {
			String URL = "http://openapi.seoul.go.kr:8088/51554a537573656f373565746c7558/json/TbPublicWifiInfo/1/1/";
			URL url = new URL(URL);
			HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
			httpConn.setRequestMethod("GET");
			httpConn.setRequestProperty("Content-type", "application/json");
			BufferedReader br;
			
			if(httpConn.getResponseCode() >= 200 && httpConn.getResponseCode() <= 300) {
				br = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
			} else {
				br = new BufferedReader(new InputStreamReader(httpConn.getErrorStream()));
			}
			
			StringBuilder sb = new StringBuilder();
			String line;
			
			while ((line = br.readLine()) != null) {
					sb.append(line);
			}
			
			Gson gson = new Gson();
			WifiJson wifiJson = gson.fromJson(sb.toString(), WifiJson.class);
			Row[] wifiRows;
			int listTotalCount = wifiJson.getTbPublicWifiInfo().getList_total_count();
			totalWifiCount = listTotalCount;
			int totalPage = listTotalCount / 1000;
			int remainTotalCount = listTotalCount % 1000;
			totalPage = remainTotalCount == 0 ? totalPage : totalPage++ ;
			sb.setLength(0);
			
			
			for (int i = 0; i < totalPage; i++) {
				String urlFormat;
				if (i == (totalPage-1)) {
					urlFormat = String.format("http://openapi.seoul.go.kr:8088/51554a537573656f373565746c7558/json/TbPublicWifiInfo/%d/%d/", i*1000+1, i*1000+remainTotalCount);
				} else {
					urlFormat = String.format("http://openapi.seoul.go.kr:8088/51554a537573656f373565746c7558/json/TbPublicWifiInfo/%d/%d/", i*1000+1, (i+1)*1000);
				}
				url = new URL(urlFormat);
				httpConn = (HttpURLConnection) url.openConnection();
				httpConn.setRequestMethod("GET");
				httpConn.setRequestProperty("Content-type", "application/json");
				
				br = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
				
				while ((line = br.readLine()) != null) {
					sb.append(line);
				}
				wifiJson = gson.fromJson(sb.toString(), WifiJson.class);
				wifiRows = wifiJson.getTbPublicWifiInfo().getRow();
				sb.setLength(0);
				
				String sql = "update wifi_info set X_SWIFI_WRDOFC = ?, X_SWIFI_MAIN_NM = ?, X_SWIFI_ADRES1 = ?, X_SWIFI_ADRES2 = ?, X_SWIFI_INSTL_FLOOR = ?, X_SWIFI_INSTL_TY = ?, X_SWIFI_INSTL_MBY = ?, X_SWIFI_SVC_SE = ?, X_SWIFI_CMCWR = ?, X_SWIFI_CNSTC_YEAR = ?, X_SWIFI_INOUT_DOOR = ?, X_SWIFI_REMARS3 = ?, LAT = ?, LNT = ?, WORK_DTTM = ? where X_SWIFI_MGR_NO = ?;";
				pstmt = conn.prepareStatement(sql);
				int affected = 0;
				
				for (int j = 0; j < wifiRows.length; j++) {
					pstmt.setString(1, wifiRows[j].getWrdofc());
					pstmt.setString(2, wifiRows[j].getMainNm());
					pstmt.setString(3, wifiRows[j].getAdres1());
					pstmt.setString(4, wifiRows[j].getAdres2());
					pstmt.setString(5, wifiRows[j].getInstlFloor());
					pstmt.setString(6, wifiRows[j].getInstlTy());
					pstmt.setString(7, wifiRows[j].getInstlMby());
					pstmt.setString(8, wifiRows[j].getSvcSe());
					pstmt.setString(9, wifiRows[j].getCmcwr());
					pstmt.setString(10, wifiRows[j].getCnstcYear());
					pstmt.setString(11, wifiRows[j].getInoutDoor());
					pstmt.setString(12, wifiRows[j].getRemars3());
					pstmt.setString(13, wifiRows[j].getLat());
					pstmt.setString(14, wifiRows[j].getLnt());
					pstmt.setString(15, wifiRows[j].getWorkDttm());
					pstmt.setString(16, wifiRows[j].getMgrNo());
				
					affected = pstmt.executeUpdate();
				}
				
				if (affected > 0) {
					System.out.println("Success");
				} else {
					System.out.println("Fail");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<String[]> load(double lat, double lnt, int start, int count) {
		if (conn == null) {
			System.out.println("Null Connection");
			return null;
		}
		
		ArrayList<String[]> result = new ArrayList<>();
		
		try {
			String sql = String.format("select round((6371 * acos(cos(radians(%f)) * cos(radians(w.LAT)) * cos(radians(w.LNT) - radians(%f)) + sin(radians(%f)) * sin(radians(w.LAT)))), 2) as 'DISTANCE(KM)', w.* from wifi_info w order by cast(`DISTANCE(KM)` as decimal(10,2)) limit %d, %d;", lat, lnt, lat, start, count);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String[] info = new String[17];
				
				for (int i = 0; i < info.length; i++) {
					info[i] = rs.getString(i+1);
				}
				
				result.add(info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public ArrayList<String[]> selectDetail(String mgrNo) {
		if (conn == null) {
			System.out.println("Null Connection");
			return null;
		}
		
		ArrayList<String[]> result = new ArrayList<>();
		
		try {
			String sql = String.format("select * from wifi_info where X_SWIFI_MGR_NO = '%s'", mgrNo);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String[] info = new String[16];
				
				for (int i = 0; i < info.length; i++) {
					info[i] = rs.getString(i+1);
				}
				
				result.add(info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public void createHistory() {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		}
		
		try {
			StringBuilder sb = new StringBuilder();
			String sql;
			
			sb.append("CREATE TABLE LOCATION_HISTORY (\r\n");
			sb.append("	LH_ID     INT          NOT NULL COMMENT '관리번호',\r\n");
			sb.append("	X_COOR    VARCHAR(255) NULL     COMMENT 'X좌표',\r\n");
			sb.append("	Y_COOR    VARCHAR(255) NULL     COMMENT 'Y좌표',\r\n");
			sb.append("	WORK_DTTM DATETIME     NULL     COMMENT '작업일자'\r\n");
			sb.append(")\r\n");
			sb.append("COMMENT '위치 히스토리';");
			
			sql = sb.toString();
			sb.setLength(0);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
			
			sb.append("ALTER TABLE LOCATION_HISTORY\r\n");
			sb.append("	ADD CONSTRAINT PK_LOCATION_HISTORY\r\n");
			sb.append("	PRIMARY KEY (\r\n");
			sb.append("	LH_ID\r\n");
			sb.append("	);");
			
			sql = sb.toString();
			sb.setLength(0);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
			
			sb.append("ALTER TABLE LOCATION_HISTORY\r\n");
			sb.append("	MODIFY COLUMN LH_ID INT NOT NULL AUTO_INCREMENT COMMENT '관리번호';");
			
			sql = sb.toString();
			sb.setLength(0);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
			
			sb.append("ALTER TABLE LOCATION_HISTORY\r\n");
			sb.append("	AUTO_INCREMENT = 1;");
			
			sql = sb.toString();
			sb.setLength(0);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void saveHistory(double lat, double lnt) {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		} else if (!this.isValidTable("location_history")) {
			this.createHistory();
		}
		
		try {
			String sql = "insert into location_history (X_COOR, Y_COOR, WORK_DTTM) values (?, ?, NOW());";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, String.valueOf(lat));
			pstmt.setString(2, String.valueOf(lnt));
			
			int affected = pstmt.executeUpdate();
			
			if (affected > 0) {
				System.out.println("Success");
			} else {
				System.out.println("Fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<String[]> loadHistory() {
		if (conn == null) {
			System.out.println("Null Connection");
			return null;
		}
		
		ArrayList<String[]> result = new ArrayList<>();
		
		try {
			String sql = "select * from location_history;";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String[] info = new String[4];
				
				for (int i = 0; i < info.length; i++) {
					info[i] = rs.getString(i+1);
				}
				
				result.add(info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public boolean deleteHistory(String ID) {
		if (conn == null) {
			System.out.println("Null Connection");
			return false;
		}
		
		try {
			String sql = "delete from location_history where LH_ID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ID);
			
			int affected = pstmt.executeUpdate();
			
			if (affected > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public ArrayList<String> loadBookmarkNames() {
		if (conn == null) {
			System.out.println("Null Connection");
			return null;
		}
		
		ArrayList<String> result = new ArrayList<>();
		
		try {
			String sql = "show tables like '%bookmark%';";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String str = rs.getString(1);
				String subbedStr = str.substring(str.indexOf("_")+1);
				result.add(subbedStr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public ArrayList<String[]> loadBookmark(String name) {
		if (conn == null) {
			System.out.println("Null Connection");
			return null;
		}
		
		ArrayList<String[]> result = new ArrayList<>();
		
		try {
			String sql = String.format("select * from BOOKMARK_%s;", name);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String[] info = new String[18];
				
				for (int i = 0; i < info.length; i++) {
					info[i] = rs.getString(i+1);
				}
				
				result.add(info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public void createBookmark(String name) {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		}
		
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("CREATE TABLE IF NOT EXISTS BOOKMARK_").append(name).append(" (\r\n");
			sb.append("	X_SWIFI_MGR_NO      VARCHAR(255) NOT NULL COMMENT '관리번호',\r\n");
			sb.append("	X_SWIFI_WRDOFC      VARCHAR(255) NULL     COMMENT '자치구',\r\n");
			sb.append("	X_SWIFI_MAIN_NM     VARCHAR(255) NULL     COMMENT '와이파이명',\r\n");
			sb.append("	X_SWIFI_ADRES1      VARCHAR(255) NULL     COMMENT '도로명주소',\r\n");
			sb.append("	X_SWIFI_ADRES2      VARCHAR(255) NULL     COMMENT '상세주소',\r\n");
			sb.append("	X_SWIFI_INSTL_FLOOR VARCHAR(255) NULL     COMMENT '설치위치(층)',\r\n");
			sb.append("	X_SWIFI_INSTL_TY    VARCHAR(255) NULL     COMMENT '설치유형',\r\n");
			sb.append("	X_SWIFI_INSTL_MBY   VARCHAR(255) NULL     COMMENT '설치기관',\r\n");
			sb.append("	X_SWIFI_SVC_SE      VARCHAR(255) NULL     COMMENT '서비스구분',\r\n");
			sb.append("	X_SWIFI_CMCWR       VARCHAR(255) NULL     COMMENT '망종류',\r\n");
			sb.append("	X_SWIFI_CNSTC_YEAR  VARCHAR(255) NULL     COMMENT '설치년도',\r\n");
			sb.append("	X_SWIFI_INOUT_DOOR  VARCHAR(255) NULL     COMMENT '실내외구분',\r\n");
			sb.append("	X_SWIFI_REMARS3     VARCHAR(255) NULL     COMMENT 'WIFI접속환경',\r\n");
			sb.append("	LAT                 VARCHAR(255) NULL     COMMENT 'Y좌표',\r\n");
			sb.append("	LNT                 VARCHAR(255) NULL     COMMENT 'X좌표',\r\n");
			sb.append("	WORK_DTTM           DATETIME     NULL     COMMENT '작업일자',\r\n");
			sb.append("	PLACE_ORDER         INT          NULL     COMMENT '순서',\r\n");
			sb.append("	DISTANCE            VARCHAR(255) NULL     COMMENT '거리'\r\n");
			sb.append(")\r\n");
			sb.append("COMMENT 'TABLE2';\r\n");
			
			String sql = sb.toString();
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
			sb.setLength(0);
			
			sb.append("ALTER TABLE BOOKMARK_").append(name).append("\r\n");
			sb.append("	ADD CONSTRAINT\r\n");
			sb.append("	PRIMARY KEY IF NOT EXISTS (\r\n");
			sb.append("	X_SWIFI_MGR_NO\r\n");
			sb.append("	);\r\n");
			
			sql = sb.toString();
			pstmt = conn.prepareStatement(sql);
			int affected = pstmt.executeUpdate();
			
			if (affected > 0) {
				System.out.println("Success");
			} else {
				System.out.println("Fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteBookmark(String name) {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		}
		
		try {
			String sql = String.format("drop table BOOKMARK_%s", name);
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteBookmarkItem(String name, String mgrNo) {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		}
		
		try {
			String sql = String.format("delete from BOOKMARK_%s where X_SWIFI_MGR_NO = ?", name);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mgrNo);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void saveBookmark(String name, String mgrNo, String distance) {
		if (conn == null) {
			System.out.println("Null Connection");
			return;
		} else if (this.checkDup("BOOKMARK_"+name, mgrNo)) {
			System.out.println("Dup");
			return;
		}
		
		try {
			StringBuilder sb = new StringBuilder();
			
			sb.append("insert into BOOKMARK_").append(name).append(" (X_SWIFI_MGR_NO, X_SWIFI_WRDOFC, X_SWIFI_MAIN_NM, X_SWIFI_ADRES1, X_SWIFI_ADRES2, X_SWIFI_INSTL_FLOOR,\n");
			sb.append("X_SWIFI_INSTL_TY, X_SWIFI_INSTL_MBY, X_SWIFI_SVC_SE, X_SWIFI_CMCWR, X_SWIFI_CNSTC_YEAR, X_SWIFI_INOUT_DOOR, X_SWIFI_REMARS3, LAT,\n");
			sb.append("LNT, WORK_DTTM) select * from wifi_info where X_SWIFI_MGR_NO = ?");
			
			String sql = sb.toString();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mgrNo);
			pstmt.executeUpdate();
			sb.setLength(0);
			
			sb.append("update BOOKMARK_").append(name).append(" set PLACE_ORDER = ?, DISTANCE = ? where X_SWIFI_MGR_NO = ?");
			sql = sb.toString();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "1");
			pstmt.setString(2, distance);
			pstmt.setString(3, mgrNo);
			pstmt.executeUpdate();
			sb.setLength(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean checkDup(String tableName, String mgrNo) {
		try {
			String sql = String.format("select exists (select * from %s where X_SWIFI_MGR_NO = '%s') as success;", tableName, mgrNo);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			int affected = 0;
			
			if (rs.next()) {
				affected = rs.getInt(1);
			}
			
			if (affected > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
}