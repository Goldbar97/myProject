package project1;

import lombok.Data;
import lombok.AllArgsConstructor;
import com.google.gson.annotations.SerializedName;

@Data
@AllArgsConstructor
public class WifiJson {
	private TbPublicWifiInfo TbPublicWifiInfo;
	
	@Data
	@AllArgsConstructor
	public class TbPublicWifiInfo {
		private int list_total_count;
		private Result RESULT;
		private Row[] row;
		
		@Data
		@AllArgsConstructor
		public class Result {
			private String CODE;
			private String MESSAGE;
		}
		
		@Data
		@AllArgsConstructor
		public class Row {
			@SerializedName("X_SWIFI_MGR_NO")
			private String mgrNo;
			
			@SerializedName("X_SWIFI_WRDOFC")
			private String wrdofc;
			
			@SerializedName("X_SWIFI_MAIN_NM")
			private String mainNm;
			
			@SerializedName("X_SWIFI_ADRES1")
			private String adres1;
			
			@SerializedName("X_SWIFI_ADRES2")
			private String adres2;
			
			@SerializedName("X_SWIFI_INSTL_FLOOR")
			private String instlFloor;
			
			@SerializedName("X_SWIFI_INSTL_TY")
			private String instlTy;
			
			@SerializedName("X_SWIFI_INSTL_MBY")
			private String instlMby;
			
			@SerializedName("X_SWIFI_SVC_SE")
			private String svcSe;
			
			@SerializedName("X_SWIFI_CMCWR")
			private String cmcwr;
			
			@SerializedName("X_SWIFI_CNSTC_YEAR")
			private String cnstcYear;
			
			@SerializedName("X_SWIFI_INOUT_DOOR")
			private String inoutDoor;
			
			@SerializedName("X_SWIFI_REMARS3")
			private String remars3;
			
			@SerializedName("LAT")
			private String lat;
			
			@SerializedName("LNT")
			private String lnt;
			
			@SerializedName("WORK_DTTM")
			private String workDttm;
		}
	}
}
